THIS FILE IS TO DISCLOSE ANY INFORMATION ABOUT THE CURRENT WEBSITE'S STATE.

Webpages are fully intergrated into play, but the bootstrap is not working properly for some reason, despite being in the main.scala.html file code.

To allow this project to be properly corrected, the CRUD, and semi-fuctional Login feature had to be left out due to this situation in the current state of the CA.

The version I used was WebDev2016b which outdated so that could be the reason fot the bootstrap not being properly applied...
