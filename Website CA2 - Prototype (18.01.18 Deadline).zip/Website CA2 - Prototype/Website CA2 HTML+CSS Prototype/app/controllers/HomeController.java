package controllers;

import play.mvc.*;
import views.html.*;

/**
 * This controller contains an action to handle HTTP requests
 * to the application's home page.
 */
public class HomeController extends Controller {

    /**
     * An action that renders an HTML page with a welcome message.
     * The configuration in the <code>routes</code> file means that
     * this method will be called when the application receives a
     * <code>GET</code> request with a path of <code>/</code>.
     */
	 
/** Index(Home) Page **/
    public Result index() {
        return ok(views.html.index.render());
    }

/** League of Legends Pages **/

    public Result LoLGame() {
        return ok(views.html.LoLGame.render());
    }
	
	public Result LoLTeams() {
        return ok(views.html.LoLTeams.render());
    }
	
	public Result LoLTournaments() {
        return ok(views.html.LoLTournaments.render());
    }

// /** SMITE Pages **/

	public Result SMITEGame() {
        return ok(views.html.SMITEGame.render());
    }
	
	public Result SMITETeams() {
        return ok(views.html.SMITETeams.render());
    }
	
	public Result SMITETournaments() {
        return ok(views.html.SMITETournaments.render());
    }

// /** Counter Strike: Global Offensive Pages **/

	public Result CSGOGame() {
        return ok(views.html.CSGOGame.render());
    }
	
	public Result CSGOTeams() {
        return ok(views.html.CSGOTeams.render());
    }
	
	public Result CSGOTournaments() {
        return ok(views.html.CSGOTournaments.render());
    }

// /** Overwatch Pages **/

	public Result OWGame() {
        return ok(views.html.OWGame.render());
    }
	
	public Result OWTeams() {
        return ok(views.html.OWTeams.render());
    }
	
	public Result OWTournaments() {
        return ok(views.html.OWTournaments.render());
    }
	
// /** About Page **/
	public Result about() {
		return ok(views.html.about.render());
	}

// /** MyAccount Page **/
	public Result MyAccount() {
		return ok(views.html.MyAccount.render());
	}
	
//	/** Users Table Page(STATIC) **/
	public Result users() {
		return ok(views.html.users.render());
	}
	
//	/** Add User Page **/
	public Result addUser() {
		return ok(views.html.addUser.render());
	}
	

}
