THIS FILE IS TO DISCLOSE ANY INFORMATION ABOUT THE CURRENT WEBSITE'S STATE.

As it currently is, the website is MISSING ALL TEAM/TOURNEYS PAGES. 
All the other pages that are present in the files are fully working in terms of navigation and none of the links are broken.

The following pages are missing but are being worked on:

SMITE-Teams.html
SMITE-Tournaments.html
CSGO-Teams.html
CSGO-Tournaments.html
LOL-Teams.html
LOL-Tournaments.html
OW-Teams.html
OW-Tournaments.html

All these file are not going to take the user anywhere on the website yet but will be done over the next week.
