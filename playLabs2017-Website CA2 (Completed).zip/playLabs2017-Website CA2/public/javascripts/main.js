
//function returns true if clicked yes, otherwise false
function confirmDel() {
    return confirm('Are you sure?');
}