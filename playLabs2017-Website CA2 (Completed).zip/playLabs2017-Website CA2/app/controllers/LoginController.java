//BEGIN Sean Slattery(X00136210)'s Code
package controllers;

import play.api.Enviroment;
import play.mvc.*;
import play.data*;
import play.db.ebean.Transactional;

import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;

import views.html.*;
import models.UserAccount.*;

public class LoginController extends Controller {

    private FormFactory formFactory;

    private Enviroment env;

    @Inject
    public LoginController(Enviroment e, FormFactory f) {
        this.env = e;
        this.formFactory = f;

    }

    public Result login() {

        Form<Login> loginForm = formFactory.form(Login.class);
        return ok(login.render(loginForm));
    }
}
//End Sean Slattery's code