package controllers;

import play.mvc.*;

import play.api.Enviroment;
import play.data.*;
import play.db.ebean.Transactional;

//import views
import views.html.*;

import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;

/**
 * This controller contains an action to handle HTTP requests
 * to the application's home page.
 */
public class HomeController extends Controller {

    /**
     * An action that renders an HTML page with a welcome message.
     * The configuration in the <code>routes</code> file means that
     * this method will be called when the application receives a
     * <code>GET</code> request with a path of <code>/</code>.
     */
//BEGIN Sean Slattery(X00136210)'s Code

    //Declare a private FormFactory instance
    private FormFactory formFactory;

    //Inject an instance of FormFactory it into the controller via its constructor
    @Inject
    public HomeController(FormFactory f) {
        this.formFactory = f;
    }

    public Result Index() {
        //Render the index view (Index.scala.html)
        return ok(Index.render());
    }
    //Game Pages
    public Result LOLGame() {
        //Render the LOL page view (LOL.scala.html)
        return ok(LOLGame.render());
    }

    public Result SMITEGame() {
        //Render the SMITE page view (SMITE.scala.html)
        return ok(SMITEGame.render());
    }

    public Result CSGOGame() {
        //Render the CSGO page view (Index.scala.html)
        return ok(CSGOGame.render());
    }

    public Result OWGame() {
        //Render the OW page view (Index.scala.html)
        return ok(OWGame.render());
    }

    //Teams and Tournaments Pages
    public Result LOLTeams() {
        //Render the LOL-Teams page view (LOL-Teams.scala.html)
        return ok(LOLTeams.render());
    }

    public Result LOLTournaments() {
        //Render the LOL-Tournaments page view (LOL-Tournaments.scala.html)
        return ok(LOLTournaments.render());
    }  

    public Result SMITETeams() {
        //Render the SMITE-Teams page view (SMITE-Teams.scala.html)
        return ok(SMITETeams.render());
    }

    public Result SMITETournaments() {
        //Render the SMITE-Tournaments page view (SMITE-Tournaments.scala.html)
        return ok(SMITETournaments.render());
    }

    public Result CSGOTeams() {
        //Render the CSGO-Teams page view (CSGO-Teams.scala.html)
        return ok(CSGOTeams.render());
    }

    public Result CSGOTournaments() {
        //Render the CSGO-Tournaments page view (CSGO-Tournaments.scala.html)
        return ok(CSGOTournaments.render());
    }

    public Result OWTeams() {
        //Render the OW-Teams page view (OW-Teams.scala.html)
        return ok(OWTeams.render());
    }

    public Result OWTournaments() {
        //Render the OW-Tournaments page view (OW-Tournaments.scala.html)
        return ok(OWTournaments.render());
    }

    //About Us Page 
    public Result AboutUs() {
        //Render the AboutUs page view (AboutUs.scala.html)
        return ok(AboutUs.render());
    }

    //MyAccount Page (NEED THE LOGIN PART DONE-LAB 10/11)
    public Result Account() {
        //Render the Account view (My-Account.scala.html)
        return ok(Account.render());
    }

     //Admins Users Page 
    public Result Users() {
        List<UserAccount> usersList = UserAccount.findAll();

        return ok(Users.render(usersList));
    }

    //Add Users page
    public Result addUsers() {
        Form<UserAccount> userForm = formFactory.form(UserAccount.class);
        return ok(addUsers.render(userForm));
    }

    //Add Users Submit
     public Result addUsersSubmit() {

        //retrieve the submitted form object (bind from the HTTP request)
        Form<UserAccount> newUserForm = formFactory.form(UserAccount.class).bindFormRequest();

        //check for errors (based on constraints set in the UserAccount class)
        if (newUserForm.hasErrors()) {
            //display the form again by returning a bad request
            return badRequest(addUsers.render(newUserForm));
        } else {
            //no errors found - extract the user's' detail from the form
            UserAccount newUsers = newUserForm.get();

            //A new , unsaved, user will not have an id
            if (newUsers.getId() == null) {
                //Save to the object to the users table
                newUsers.save();
            }
            else if (newUsers.getId() != null) {
                //User exists
                newUser.update();
            }
            
            //set a success message in  flash (for display in return view)
            flash("success", "User: " + newUsers.getGame() + " was added");

            //redirect to the index page
            return redirect(controllers.routes.HomeController.Index());
        }
    }

    //Delete User
    public Result deleteUser(Long id) {

        //Find user by id and call the delete method
        UserAccount.find.ref(id).delete();

        //Add a message to flash session
        flash("Success ", "User has been deleted");

        //Redirect back to index page
        return redirect(routes.HomeController.Index());
    }
}
//END Sean Slattery(X00136210)