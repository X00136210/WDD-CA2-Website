//BEGIN Sean Slattery(X00136210)'s Code
package models.UserAccount;

//A view Model class to back the Login Form
public class Login {

    private String userEmail;
    private String userPassword;

    //Validate method - during error checking
    //alter form based on a login obj. has been submitted
    public String validate() {

        //Call the static authenticate method in UserAccount
        if(UserAccount.authenticate(getUserEmail(), getUserPassword())== null) {
            return "Invalid user or password";
        }
        return null;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }
}
//END Sean Slattery's code