//BEGIN Sean Slattery(X00136210)'s Code
package models.UserAccount;

import java.util.*;
import javax.persistence.*;

import io.ebean.*;
import play.data.format.*;
import paly.data.validation.*;

@Entity
public class UserAccount extends Model {

    //Properties
    @Id
    private Long id;

    @Constraints.Required
    private String userName;

    @Constraints.Required
    private String userEmail;

    @Constraints.Required
    private String userPassword;

    //Default Constructor
    public UserAccount() {

    }

    //Constructor to initialse obj.
    public UserAccount(Long id, String userName, String userEmail, String userPassword) {
        this.id = id;
        this.userName = userName;
        this.userEmail = userEmail;
        this.userPassword = userPassword;
    }

    //Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

     public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

     public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    //Generic query finder for entity Product with id of type Long
    public static final Finder<Long, UserAccount> find = new Finder<>(UserAccount.class);

    //Return an array list of all project objects
    public static final List<UserAccount> findAll() {
        return UserAccount.find.all();
    }

    //Standard method to authenicate based on username and password
    //returns user if found, else returns null
    public static User authenticate(String userEmail, String userPassword) {
        return find.query().where().eq("email", userEmail).eq("password", userPassword).findUnique();
    }
}
//END Sean Slattery's Code