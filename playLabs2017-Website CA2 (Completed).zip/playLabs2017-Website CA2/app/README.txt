THIS FILE IS TO DISCLOSE ANY INFORMATION ABOUT THE CURRENT WEBSITE'S STATE.

-Webpages(Done)
-CRUD(Create and Delete are implemented, update was ignored)
-Login(Not fully finished, ran out of time due to poor time management -Sean)
