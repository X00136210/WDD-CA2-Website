# --- user dataset - SCRIPT MUST BE APPLIED FOR BY EVOLUTION ERROR

# --- !Ups

# -- BEGIN Sean Slattery(X00136210)'s Code
insert into users (id, username, email, password) values (1, 'Yeo', 'steeleYeo@test.com', 'WetherIsGrey');

insert into users (id, username, email, password) values (2, 'Hauntzer', 'hauntedZero@gmail.com', 'DeadSilence');

insert into users (id, username, email, password) values (3, 'Titan', 'moonOfATitan@hotmail.com', 'fallenMOOn');

insert into users (id, username, email, password) values (4, 'Yamibito', 'cursedForLife@gmail.com', 'shibitoSucks');

insert into users (id, username, email, password) values (5, 'IoOhThree', 'thePyramidion@gmail.com', 'VexedForAwhile');

insert into users (id, username, email, password) values (6, 'TheJovianGuard', 'guardianDispached@hotmail.com', 'IntersteallarDynasty');

insert into users (id, username, email, password) values (7, 'RetroZones', 'seeThePast@hotmail.com', 'AllThingsConverge');

insert into users (id, username, email, password) values (8, 'Foster', 'GPfive@gmail.com', 'DoshLoverZedKiller');

#--END Sean's Code

